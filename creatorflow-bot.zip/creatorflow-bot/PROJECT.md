# CreatorFlow — Produktvision

## Was ist CreatorFlow?

CreatorFlow ist ein Auftragsmanagement-System für Content-Agenturen die mit freiberuflichen
Creators arbeiten. Es automatisiert den Workflow von der Auftragsvergabe bis zur Lieferung
über Telegram, Instagram, TikTok, OnlyFans, Fansly und Maloum.

## Warum existiert dieses System?

Content-Agenturen koordinieren heute alles über Telegram-Chats. Links zu Beispielvideos
werden als Nachrichten geschickt, fertige Videos als Replies zurückgeschickt. Das führt zu:
- Wochenlangem Scrollen um Aufträge zu finden
- Handschriftlichen Listen die veralten
- Rückständen die in der nächsten Woche verschwinden
- Kein Überblick wer was geliefert hat

## Kernprinzipien

**1. Telegram bleibt der Arbeitskanal**
Der Bot liest mit — Agentur und Creator müssen ihren Workflow nicht ändern.
Der Bot ist ein unsichtbarer Layer der Daten strukturiert erfasst.

**2. Datenisolation ist nicht verhandelbar**
Pornografischer Content mit kommerziellem Wert. Jede DB-Query muss
creator_id oder agency_id prüfen. Kein Cross-Access ist möglich.

**3. Nichts wird hart gelöscht**
Soft Delete überall. Audit-Trail für jede Status-Änderung.
Das System dient als Beweismittel bei Streitigkeiten.

**4. EU-DSGVO ist Pflicht, nicht Optional**
Serverstandort Frankfurt. Logs nach 90 Tagen. Videos nie selbst speichern.
AVV mit jeder Agentur unterzeichnen.

**5. Phase 2 darf keinen Umbau erfordern**
Alle Telegram-IDs nullable. Business-Logik framework-agnostisch.
Web-App ist ein weiterer Client auf derselben DB.

## Zielgruppe Phase 1

Eine Creator, eine Agentur. Beweis dass das Konzept funktioniert.

## Zielgruppe Phase 2-4

Bis 500 Creator, mehrere Agenturen, SaaS-Modell mit Stripe.

## Was dieses System NICHT ist

- Kein Video-Hosting (Videos bleiben auf Telegram/Plattformen)
- Kein Social-Media-Scheduling-Tool
- Kein Creator-Recruiting-Tool
- Kein Zahlungsabwickler zwischen Agentur und Creator

## Technische Entscheidungen und warum

- **Node.js ESM überall** — kein Mischen von CJS und ESM
- **postgres.js statt ORM** — direktes SQL, vollständige Kontrolle über Queries
- **API /api/v1/** — Breaking Changes ohne Dashboard-Ausfall möglich
- **Zod auf allen Routes** — kein unvalidierter Input erreicht die DB
- **Soft Delete** — regulatorische Anforderungen und Audit-Trail
- **Render statt Railway** — bestehender Account, EU-Hosting verfügbar
- **Neon Frankfurt** — DSGVO-Compliance für sensible Datenkategorie
