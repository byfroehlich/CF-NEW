# CreatorFlow — Backlog

Alles hier ist bewusst zurückgestellt. Nicht vergessen, nicht verloren.
Vor der Implementierung jeweils prüfen ob die Architektur noch passt.

---

## Sicherheit

### Webhook statt Polling (Priorität: Hoch)
Bot läuft aktuell im Polling-Modus. Für Production-Betrieb ist Webhook sicherer:
- Telegram sendet Updates an `https://api.onrender.com/webhook/<SECRET>`
- Secret verhindert dass jemand gefälschte Updates einschleust
- Benötigt: HTTPS-Endpunkt (Render stellt das), Webhook-Secret in .env
- Telegraf unterstützt Webhook nativ: `bot.launch({ webhook: { domain, secretToken } })`

### 2FA für Admin/Agency-Accounts (Priorität: Hoch)
Bei pornografischem Content mit kommerziellem Wert ist 2FA für privilegierte Accounts sinnvoll.
- TOTP (Google Authenticator / Aegis) via `otplib` npm-Paket
- QR-Code bei erstem Login scannen
- Bei Login: Passwort + 6-stelliger Code
- Recovery-Codes generieren und sicher aufbewahren
- Schema: `totp_secret TEXT` auf `users`, `totp_enabled BOOLEAN DEFAULT false`

### Session-Management (Priorität: Mittel)
Aktuell keine Möglichkeit "alle anderen Sessions abmelden".
- Alle Refresh Tokens eines Users auf `revoked = true` setzen
- API-Endpoint: `POST /api/v1/auth/revoke-all`
- Dashboard: "Alle anderen Geräte abmelden" Button in Profil
- Admin kann alle Sessions eines Users revoken

### Dependabot (Priorität: Mittel)
GitHub Dependabot aktivieren für automatische Security-Updates:
- `.github/dependabot.yml` anlegen
- npm-Pakete wöchentlich prüfen
- Automatische PRs für Patch-Updates

### Content Security Policy verfeinern (Priorität: Mittel)
Helmet.js setzt Default-CSP. Für Production explizit konfigurieren:
```js
helmet.contentSecurityPolicy({
  directives: {
    defaultSrc: ["'self'"],
    scriptSrc: ["'self'"],
    styleSrc: ["'self'", "'unsafe-inline'"],  // Tailwind benötigt das
    imgSrc: ["'self'", "data:", "https:"],
    connectSrc: ["'self'", process.env.ALLOWED_ORIGIN],
  }
})
```

---

## Features

### Video-Upload via Cloudflare R2 (Priorität: Mittel für Phase 2)
Wenn Creators Videos direkt in der App hochladen sollen statt per Telegram:
- Cloudflare R2: EU-Rechenzentrum verfügbar, kein Egress-Preis
- Presigned URLs: Browser lädt direkt zu R2 hoch, kein API-Bottleneck
- Schema: `deliveries` bekommt `r2_key TEXT` neben `telegram_file_id`
- Maximale Dateigröße serverseitig begrenzen (empfohlen: 500MB)
- Content-Type validieren (nur video/*)
- Alte Videos nach 90 Tagen automatisch aus R2 löschen (R2 Lifecycle Rules)

### OpenAPI/Swagger Dokumentation (Priorität: Niedrig)
Wenn externe Entwickler oder die Agentur eigene Integrationen bauen:
- `swagger-jsdoc` + `swagger-ui-express`
- Alle Routes mit JSDoc annotieren
- Zugänglich unter `/api/docs` (nur mit Admin-Token)

### PgBouncer Connection Pooling (Priorität: Niedrig bis Phase 3)
Ab ~50 simultanen API-Requests werden DB-Verbindungen zum Engpass:
- Neon hat eingebautes Connection Pooling (Serverless-Modus)
- Alternativ: PgBouncer als separater Render-Service
- Verbindungs-URL wechselt zu Pooler-Endpunkt

### Stripe Abrechnung (Priorität: Niedrig — Phase 3)
Für SaaS-Modell mit mehreren Agenturen:
- Stripe Checkout für Onboarding
- Webhook: `invoice.payment_succeeded` → Agency-Account aktivieren
- Schema: `agencies` bekommt `stripe_customer_id`, `plan`, `plan_expires_at`
- Render Cron: täglich Ablauf-Datum prüfen, inaktive Accounts sperren

### Multi-Bot-Instanzen (Priorität: Niedrig — Phase 3)
Ein Bot-Prozess kann theoretisch hunderte Chats verarbeiten.
Ab ~500 Creator könnte Latenz zum Problem werden:
- Mehrere Bot-Instanzen mit unterschiedlichen Creator-Subsets
- Load-Balancing via DB: `creators.bot_instance_id`

---

## Infrastruktur

### Automatisiertes Backup testen (Priorität: Hoch)
`scripts/backup.sh` ist vorhanden aber noch nie getestet.
Vor Go-Live mit echten Daten:
1. Backup durchführen
2. Auf leere Test-DB restoren
3. Daten prüfen
4. Recovery-Zeit messen und dokumentieren

### UptimeRobot Konfiguration (Priorität: Hoch)
Noch nicht eingerichtet. Vor Go-Live:
1. Account auf uptimerobot.com anlegen (kostenlos)
2. Monitor für API `/health` Endpoint anlegen (alle 5 Min)
3. Telegram-Alert bei Ausfall konfigurieren
4. E-Mail-Alert als Backup

### Render Free Tier Sleep (Priorität: Mittel)
Web Services auf Render Free Tier schlafen nach 15 Min Inaktivität ein.
Erstes Request morgens dauert ~30 Sekunden.
Lösung A (kostenlos): UptimeRobot pingt `/health` alle 10 Min
Lösung B (bezahlt): Render Paid Plan ~$7/Monat pro Service

---

## Rechtliches

### AVV unterzeichnen (Priorität: Kritisch vor Go-Live)
Auftragsverarbeitungsvertrag mit jeder Agentur gemäß Art. 28 DSGVO.
Entwurf von Anwalt prüfen lassen. Vor erstem Echtbetrieb unterzeichnen.

### Render DPA anfordern (Priorität: Kritisch vor Go-Live)
Data Processing Agreement mit Render.com aktiv anfordern und archivieren.
Kontakt: legal@render.com oder über Dashboard-Support.

### Neon DPA anfordern (Priorität: Kritisch vor Go-Live)
DPA mit Neon aktiv anfordern und archivieren.

### TERMS.md rechtlich prüfen (Priorität: Hoch vor Go-Live)
Der Entwurf in TERMS.md muss von einem österreichischen/deutschen Anwalt
geprüft werden bevor er gegenüber Agenturen verwendet wird.
Schwerpunkte: Haftungsbeschränkung, AUP, Jugendschutz, Datenschutz.

### Steuerrecht AT+DE klären (Priorität: Hoch)
Wenn Agentur in DE ansässig und zahlt: mögliche Betriebsstätte in DE.
Steuerberater konsultieren bevor erster Vertrag unterzeichnet wird.
Betrifft: Umsatzsteuer, Körperschaftsteuer, Gewerbesteuer.

### Markenrecherche "CreatorFlow" (Priorität: Mittel)
Prüfen ob Name bereits als Marke eingetragen:
- EU: euipo.europa.eu/eSearch
- AT: patentamt.at
- DE: dpma.de
Wenn frei: Markenschutz für AT/EU erwägen wenn SaaS-Modell kommt.

---

## Monitoring & Observability

### Strukturiertes Logging (Priorität: Niedrig)
Aktuell: console.log + DB-Tabelle.
Für Phase 3: Structured JSON Logging mit `pino`:
- Log-Level konfigurierbar per ENV
- JSON-Format für Aggregation (Grafana Loki, Datadog, etc.)

### Performance-Monitoring (Priorität: Niedrig)
Für Phase 3 wenn Latenz messbar wird:
- Response-Zeit je Endpoint messen
- Slow-Query-Log in Neon aktivieren
- EXPLAIN ANALYZE auf häufigste Queries

---

## Zuletzt aktualisiert: April 2025

---

## Zertifizierungen & Compliance-Standards

### ISO/IEC 27001 — Informationssicherheits-Management (Priorität: Niedrig — Phase 4)

Internationaler Standard für den systematischen Umgang mit Informationssicherheitsrisiken.
Kein technischer Standard sondern ein Prozessrahmen — beschreibt wie Risiken identifiziert,
dokumentiert und kontrolliert werden.

**Wann relevant:**
- Wenn Enterprise-Kunden oder große Agenturen einen Nachweis fordern
- Wenn du in Ausschreibungen mitbietest
- Wenn Versicherungen (Cyber-Haftpflicht) eine Zertifizierung voraussetzen

**Kosten:** 5.000–20.000 EUR für erstes Audit, jährliche Überwachungsaudits zusätzlich.

**Was CreatorFlow bereits erfüllt (ISO 27001 Controls):**
- Zugriffskontrollen (Rollen, JWT, Datenisolation)
- Audit-Trail (job_status_history, logs)
- Verschlüsselung in Transit (HTTPS/SSL Pflicht)
- Backup-Konzept (scripts/backup.sh)
- Logging und Monitoring (System-Log Dashboard)
- Soft Delete (Daten nicht unwiederbringlich verloren)
- Rate Limiting (Schutz vor Angriffen)

**Vorstufe ohne Zertifizierung:**
Ein internes Sicherheitsdokument das beschreibt wie Risiken gehandhabt werden
("Selbstauskunft nach ISO 27001") wird von kleineren Agenturen als Nachweis oft akzeptiert.

---

### ISO/IEC 27701 — Datenschutz-Erweiterung (Priorität: Niedrig — Phase 4)

Erweiterung zu ISO 27001 spezifisch für DSGVO-Compliance.
Beschreibt wie personenbezogene Daten im Sicherheitsmanagementsystem behandelt werden.
Erst relevant wenn ISO 27001 Basis vorhanden ist.

---

### SOC 2 Type I/II — Alternative zu ISO (Priorität: Niedrig — Phase 3/4)

Amerikanisches Pendant zu ISO 27001, wird von SaaS-Kunden häufig gefordert.

**Gute Nachricht:** Render.com und Neon haben bereits SOC 2 Zertifizierungen.
Das kann als Argument gegenüber Kunden verwendet werden:
"Unsere Infrastrukturanbieter sind SOC 2 zertifiziert."

SOC 2 für CreatorFlow selbst: erst relevant wenn Enterprise-Kunden es explizit verlangen.

---

### Cyber-Haftpflichtversicherung (Priorität: Mittel — vor Phase 3)

Bevor mehrere zahlende Agenturen auf der Plattform sind:
Eine Cyber-Haftpflichtversicherung abschließen die Schäden durch Datenpannen,
Systemausfälle und Hackerangriffe abdeckt.

Österreichische Anbieter: Allianz, Uniqa, Wiener Städtische.
Kosten für kleine Software-Unternehmen: ca. 500–2.000 EUR/Jahr je nach Deckungssumme.

---

## Zuletzt aktualisiert: April 2025
