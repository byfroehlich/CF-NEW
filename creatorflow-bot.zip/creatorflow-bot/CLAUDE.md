# CreatorFlow — Claude Code Bauanleitung v2.0

## Projektstruktur

```
creatorflow/
├── CLAUDE.md          ← Diese Datei
├── render.yaml        ← Render Deployment (alle 3 Services)
├── .gitignore         ← Secrets niemals committen
├── TERMS.md           ← Nutzungsbedingungen (Entwurf)
├── scripts/
│   └── backup.sh      ← Tägliches DB-Backup Script
├── bot/               ← Telegram Bot (Render Worker)
├── api/               ← REST API v1 (Render Web Service)
└── dashboard/         ← React App (Render Static Site)
```

---

## KRITISCH — Vor dem Start

### 1. Neon Region auf EU setzen
Neon Projekt anlegen → Region: **eu-central-1 (Frankfurt)**
Dies ist PFLICHT für DSGVO-Compliance bei sensiblen Daten.
Nachträglich nicht änderbar ohne Datenmigration.

### 2. Schema ausführen
Neon SQL Editor → `bot/src/db/schema.sql` vollständig ausführen.

### 3. Creator mit Chat-ID verknüpfen
Nach erstem `/start` des Bots:
```
https://api.telegram.org/bot<TOKEN>/getUpdates → chat.id kopieren
```
```sql
UPDATE creators SET telegram_chat_id = <CHAT_ID>
WHERE name = 'Creatorin';
```

---

## Schritt 1 — Bot

```bash
cd bot
npm install
cp .env.example .env
# .env ausfüllen: BOT_TOKEN, DATABASE_URL
node index.js   # lokal testen
```

**Bot verhält sich so:**
- Überwacht alle Chats deren `telegram_chat_id` in `creators` eingetragen ist
- Neue Nachricht mit Links → Jobs anlegen, Status-History schreiben
- Video-Reply auf bekannte Nachricht → Job als `delivered` markieren
- Heartbeat alle 5 Min → Bot-Online-Status im Admin-Dashboard sichtbar
- Montags 08:00 → automatischer Übertrag offener Jobs in neue KW
- Täglich 03:00 → Logs älter 90 Tage löschen (DSGVO)

---

## Schritt 2 — API

```bash
cd api
npm install
cp .env.example .env
# .env ausfüllen: DATABASE_URL, JWT_SECRET, SETUP_KEY, ALLOWED_ORIGIN
node index.js   # Port 3001
```

**JWT_SECRET generieren:**
```bash
node -e "console.log(require('crypto').randomBytes(64).toString('hex'))"
```

**Users anlegen (einmalig):**
```bash
# Admin
curl -X POST http://localhost:3001/api/v1/auth/setup \
  -H "Content-Type: application/json" \
  -H "x-setup-key: <SETUP_KEY>" \
  -d '{"email":"admin@app.de","password":"MeinSicheresPasswort123!","role":"admin"}'

# Agency (agency_id aus DB: SELECT id FROM agencies;)
curl -X POST http://localhost:3001/api/v1/auth/setup \
  -H "Content-Type: application/json" \
  -H "x-setup-key: <SETUP_KEY>" \
  -d '{"email":"agentur@app.de","password":"AgencyPass456!","role":"agency","agency_id":"<UUID>"}'

# Creator (creator_id aus DB: SELECT id FROM creators;)
curl -X POST http://localhost:3001/api/v1/auth/setup \
  -H "Content-Type: application/json" \
  -H "x-setup-key: <SETUP_KEY>" \
  -d '{"email":"creator@app.de","password":"CreatorPass789!","role":"creator","creator_id":"<UUID>"}'
```

**Nach dem Setup: /setup Route aus api/src/routes/auth.js entfernen**

---

## Schritt 3 — Dashboard

```bash
cd dashboard
npm install
cp .env.example .env
# VITE_API_URL auf Render-API-URL setzen
npm run dev     # lokal testen
npm run build   # Production
```

---

## API Endpoints (alle unter /api/v1/)

### Auth
```
POST /auth/login     → { access_token, refresh_token, role }
POST /auth/refresh   → { access_token, refresh_token }
POST /auth/logout    → { ok }
POST /auth/setup     → User anlegen (nur mit x-setup-key Header)
```

### Jobs
```
GET    /jobs?week=17&year=2025&platform=IG  → jobs[]
GET    /jobs/summary                         → { open, delivered, confirmed, ... }
PATCH  /jobs/:id  { status }                 → job
DELETE /jobs/:id                             → { ok }   (Soft delete)
```

### Creators
```
GET    /creators        → creators[]
PATCH  /creators/:id    → { active }
DELETE /creators/:id    → { ok }   (Soft delete, nur Admin)
```

### Logs
```
GET /logs?level=error&source=bot  → logs[]
GET /logs/stats                   → { error_1h, last_heartbeat, ... }
```

---

## Datenisolation — Rollen

| Aktion | creator | agency | admin |
|---|---|---|---|
| Eigene Jobs sehen | ✅ | ✅ alle ihrer Agentur | ✅ alle |
| Fremde Jobs sehen | ❌ | ❌ | ✅ |
| Status ändern | ✅ eigene | ✅ Agentur-Jobs | ✅ |
| Job löschen | ❌ | ✅ | ✅ |
| Creator verwalten | ❌ | ✅ eigene | ✅ |
| Logs sehen | ❌ | ✅ eigene | ✅ alle |
| Admin-Funktionen | ❌ | ❌ | ✅ |

---

## Sicherheit — Implementiert

- Rate Limiting: Login 10/15Min, API 100/Min
- Helmet.js Security Headers
- CORS auf ALLOWED_ORIGIN eingeschränkt
- JWT Access Token 24h + Refresh Token 30 Tage
- Account-Sperrung nach 10 Fehlversuchen (30 Min)
- Passwort-Policy: 12 Zeichen + Groß + Zahl + Sonderzeichen
- bcrypt 14 Runden
- Zod Input-Validierung auf allen Routes
- Soft Delete — nichts wird hard gelöscht
- Status-History — jede Änderung protokolliert

---

## Datenschutz — DSGVO

- Neon Region: eu-central-1 Frankfurt (PFLICHT)
- Videos werden NIEMALS gespeichert — nur Telegram File IDs
- Logs: automatische Löschung nach 90 Tagen (Bot + API Cron)
- Auftragsdaten: nach 12 Monaten manuell löschen
- Soft Delete: Nutzer können Löschung beantragen
- TERMS.md: Nutzungsbedingungen (vor Go-Live Anwalt prüfen lassen)
- AVV mit Agentur abschließen (Art. 28 DSGVO)

---

## Backup

`scripts/backup.sh` täglich ausführen (Render Cron Job oder externer Server):
- pg_dump → gzip → Upload Backblaze B2 (EU)
- 7 Tage täglich, 4 Wochen wöchentlich aufbewahren

---

## Render Deployment

1. GitHub Repo erstellen → Code pushen
2. Render Dashboard → "New Blueprint" → render.yaml auswählen
3. Umgebungsvariablen für jeden Service setzen
4. Deploy

**Reihenfolge:** Neon DB → Bot → API → Dashboard

---

## Umgebungsvariablen

### bot/.env
```
BOT_TOKEN=
DATABASE_URL=postgresql://...?sslmode=require
NODE_ENV=production
```

### api/.env
```
DATABASE_URL=postgresql://...?sslmode=require
JWT_SECRET=
SETUP_KEY=
ALLOWED_ORIGIN=https://creatorflow-dashboard.onrender.com
PORT=3001
NODE_ENV=production
```

### dashboard/.env
```
VITE_API_URL=https://creatorflow-api.onrender.com
```

---

## Plattform-Codes

| Code | Plattform |
|---|---|
| IG | Instagram |
| TK | TikTok |
| OF | OnlyFans |
| FL | Fansly |
| ML | Maloum |

---

## Job Status Flow

```
open → in_progress → delivered → confirmed
         ↑                ↑            ↑
      Creator          Creator      Agency/Admin
```

Jeder Übergang wird in `job_status_history` protokolliert.

---

## Hinweise für Claude Code

- Alle Dateien vollständig implementiert — nur .env Werte fehlen
- ESM überall (import/export, kein require)
- API Version: /api/v1/ — niemals ohne Versionspräfix
- Zod-Validierung auf ALLEN POST/PATCH Routes
- Datenisolation in JEDER Query prüfen (creator_id / agency_id)
- Soft Delete: WHERE deleted_at IS NULL in allen Queries
- Nach Setup: /setup Route aus auth.js entfernen
- node-cron ist auch in api/index.js importiert — package.json prüfen

---

## Testing

### Bot Tests ausführen
```bash
cd bot
npm test                    # alle Tests
npm run test:parser         # nur Parser
```

### API Tests ausführen
```bash
cd api
# .env.test mit TEST_API_URL, TEST_CREATOR_EMAIL etc. anlegen
npm test
```

### Pre-Deploy Check
```bash
bash scripts/predeploy.sh
```

---

## Monitoring einrichten (nach Deploy)

Siehe `scripts/uptimerobot.md` für vollständige Anleitung.

Kurzfassung:
1. uptimerobot.com → kostenloser Account
2. Monitor für `https://creatorflow-api.onrender.com/health` anlegen
3. Telegram-Alert einrichten
4. Zweiten Monitor zum Wachhalten (Render Sleep) anlegen

---

## Neue Dateien in dieser Version

- `PROJECT.md` — Produktvision und Kernprinzipien (Pflichtlektüre für Claude Code)
- `BACKLOG.md` — Alle zurückgestellten Features mit Implementierungshinweisen
- `bot/tests/` — Parser und WeekHelper Tests
- `api/tests/` — Auth und Datenisolation Tests
- `dashboard/src/components/ErrorState.jsx` — Offline/Server-down Handling
- `dashboard/src/components/OfflineBanner.jsx` — Echtzeit-Offline-Banner
- `scripts/predeploy.sh` — Pre-Deploy Security Checklist
- `scripts/uptimerobot.md` — Monitoring Setup Anleitung

---

## Render Free Tier — bekannte Einschränkung

Web Services schlafen nach 15 Min Inaktivität ein.
Erste Anfrage des Tages dauert bis zu 30 Sekunden.
Das Dashboard zeigt dafür eine klare Fehlermeldung mit "Erneut versuchen".
Lösung: UptimeRobot pingt `/health` alle 10 Min (kostenlos).
