import StatusBadge from './StatusBadge.jsx'
import PlatformBadge from './PlatformBadge.jsx'

const NEXT_STATUS = {
  open: 'in_progress',
  in_progress: 'delivered',
}

const NEXT_LABEL = {
  open: 'In Arbeit markieren',
  in_progress: 'Als erledigt markieren',
}

export default function JobCard({ job, onStatusChange }) {
  const canAdvance = NEXT_STATUS[job.status]
  const isCarried = !!job.carried_over_from

  return (
    <div className={`bg-white rounded-xl border p-4 space-y-3 ${
      isCarried ? 'border-orange-200' : 'border-gray-200'
    }`}>
      <div className="flex items-start justify-between gap-2">
        <div className="flex items-center gap-2 flex-wrap">
          {isCarried && (
            <span className="text-xs font-medium text-orange-600 bg-orange-50 px-2 py-0.5 rounded-full border border-orange-200">
              ↩ Übertrag
            </span>
          )}
          <PlatformBadge platform={job.platform} />
          <span className="text-xs text-gray-400">KW{job.week_number}</span>
        </div>
        <StatusBadge status={job.status} />
      </div>

      {job.source_link && (
        <a
          href={job.source_link}
          target="_blank"
          rel="noopener noreferrer"
          className="block text-xs text-indigo-600 hover:text-indigo-800 truncate"
        >
          {job.source_link}
        </a>
      )}

      {canAdvance && (
        <button
          onClick={() => onStatusChange(job.id, NEXT_STATUS[job.status])}
          className="w-full py-2.5 text-sm font-medium rounded-lg bg-indigo-600 text-white hover:bg-indigo-700 active:scale-[0.98] transition-all"
        >
          {NEXT_LABEL[job.status]}
        </button>
      )}

      {job.status === 'delivered' && (
        <p className="text-xs text-center text-green-600 font-medium">
          ✅ Geliefert — wartet auf Bestätigung
        </p>
      )}
      {job.status === 'confirmed' && (
        <p className="text-xs text-center text-indigo-600 font-medium">
          ⭐ Bestätigt
        </p>
      )}
    </div>
  )
}
