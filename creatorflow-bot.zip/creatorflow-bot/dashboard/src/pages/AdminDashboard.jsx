import { useState } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { getJobs, getSummary, updateJobStatus } from '../lib/api.js'
import { clearAuth } from '../lib/auth.js'
import { useNavigate } from 'react-router-dom'
import JobTable from '../components/JobTable.jsx'
import WeekFilter from '../components/WeekFilter.jsx'
import ErrorState from '../components/ErrorState.jsx'
import SystemLog from './SystemLog.jsx'

const PLATFORMS = ['Alle', 'IG', 'TK', 'OF', 'FL', 'ML']
const TABS = ['Aufträge', 'System']

function getCurrentWeek() {
  const now = new Date()
  const d = new Date(Date.UTC(now.getFullYear(), now.getMonth(), now.getDate()))
  const dayNum = d.getUTCDay() || 7
  d.setUTCDate(d.getUTCDate() + 4 - dayNum)
  const yearStart = new Date(Date.UTC(d.getUTCFullYear(), 0, 1))
  const week = Math.ceil((((d - yearStart) / 86400000) + 1) / 7)
  return { week, year: d.getUTCFullYear() }
}

function StatCard({ label, value, color = 'gray' }) {
  const colors = {
    gray:   'border-gray-200 text-gray-900',
    red:    'border-red-200 text-red-600',
    orange: 'border-orange-200 text-orange-600',
    green:  'border-green-200 text-green-600',
    yellow: 'border-yellow-200 text-yellow-600',
  }
  return (
    <div className={`bg-white rounded-xl border p-4 text-center ${colors[color]}`}>
      <div className="text-3xl font-bold">{value ?? '–'}</div>
      <div className="text-xs text-gray-500 mt-1">{label}</div>
    </div>
  )
}

export default function AdminDashboard() {
  const navigate = useNavigate()
  const queryClient = useQueryClient()
  const { week: cw, year: cy } = getCurrentWeek()
  const [week, setWeek] = useState(cw)
  const [year, setYear] = useState(cy)
  const [platform, setPlatform] = useState('Alle')
  const [activeTab, setActiveTab] = useState('Aufträge')

  const { data: jobs = [], isLoading, error, refetch } = useQuery({
    queryKey: ['jobs-admin', week, year, platform],
    queryFn: () => getJobs({ week, year, ...(platform !== 'Alle' && { platform }) }),
    enabled: activeTab === 'Aufträge',
  })

  const { data: summary } = useQuery({
    queryKey: ['summary', week, year],
    queryFn: () => getSummary({ week, year }),
    enabled: activeTab === 'Aufträge',
  })

  const mutation = useMutation({
    mutationFn: ({ id, status }) => updateJobStatus(id, status),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['jobs-admin'] })
      queryClient.invalidateQueries({ queryKey: ['summary'] })
    },
  })

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-gray-900 text-white px-6 py-4 sticky top-0 z-10">
        <div className="flex items-center justify-between max-w-6xl mx-auto">
          <div>
            <h1 className="font-bold text-lg">CreatorFlow Admin</h1>
            <p className="text-xs text-gray-400">Agentur-Übersicht</p>
          </div>
          <div className="flex items-center gap-4">
            {activeTab === 'Aufträge' && (
              <WeekFilter week={week} year={year} onChange={(w,y) => { setWeek(w); setYear(y) }} />
            )}
            <button onClick={() => { clearAuth(); navigate('/login') }} className="text-xs text-gray-400 hover:text-white">Abmelden</button>
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-6 py-6 space-y-6">
        <div className="flex gap-1 bg-white border border-gray-200 rounded-xl p-1 w-fit">
          {TABS.map(tab => (
            <button key={tab} onClick={() => setActiveTab(tab)}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                activeTab === tab ? 'bg-gray-900 text-white' : 'text-gray-600 hover:bg-gray-50'
              }`}>
              {tab === 'System' ? '🔧 System' : tab}
            </button>
          ))}
        </div>

        {activeTab === 'Aufträge' && (
          <>
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-4">
              <StatCard label="Gesamt"    value={summary?.total}       color="gray" />
              <StatCard label="Offen"     value={summary?.open}        color="red" />
              <StatCard label="In Arbeit" value={summary?.in_progress} color="orange" />
              <StatCard label="Geliefert" value={summary?.delivered}   color="green" />
              <StatCard label="Überträge" value={summary?.carried}     color="yellow" />
            </div>

            <div className="flex gap-2 flex-wrap">
              {PLATFORMS.map(p => (
                <button key={p} onClick={() => setPlatform(p)}
                  className={`px-4 py-1.5 rounded-lg text-sm font-medium transition-colors ${
                    platform === p ? 'bg-indigo-600 text-white' : 'bg-white border border-gray-200 text-gray-600 hover:bg-gray-50'
                  }`}>
                  {p}
                </button>
              ))}
            </div>

            {isLoading ? (
              <div className="text-center py-12 text-gray-400 text-sm">Lädt…</div>
            ) : error ? (
              <ErrorState error={error} onRetry={refetch} />
            ) : (
              <JobTable jobs={jobs}
                onStatusChange={(id, status) => mutation.mutate({ id, status })} />
            )}
          </>
        )}

        {activeTab === 'System' && <SystemLog />}
      </div>
    </div>
  )
}
