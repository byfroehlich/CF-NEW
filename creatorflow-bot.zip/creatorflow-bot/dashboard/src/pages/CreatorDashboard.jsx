import { useState } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { getJobs, updateJobStatus } from '../lib/api.js'
import { getUser, clearAuth } from '../lib/auth.js'
import { useNavigate } from 'react-router-dom'
import JobCard from '../components/JobCard.jsx'
import WeekFilter from '../components/WeekFilter.jsx'
import ErrorState from '../components/ErrorState.jsx'

const PLATFORMS = ['Alle', 'IG', 'TK', 'OF', 'FL', 'ML']

function getCurrentWeek() {
  const now = new Date()
  const d = new Date(Date.UTC(now.getFullYear(), now.getMonth(), now.getDate()))
  const dayNum = d.getUTCDay() || 7
  d.setUTCDate(d.getUTCDate() + 4 - dayNum)
  const yearStart = new Date(Date.UTC(d.getUTCFullYear(), 0, 1))
  const week = Math.ceil((((d - yearStart) / 86400000) + 1) / 7)
  return { week, year: d.getUTCFullYear() }
}

export default function CreatorDashboard() {
  const user = getUser()
  const navigate = useNavigate()
  const queryClient = useQueryClient()
  const { week: cw, year: cy } = getCurrentWeek()
  const [week, setWeek] = useState(cw)
  const [year, setYear] = useState(cy)
  const [platform, setPlatform] = useState('Alle')

  const { data: jobs = [], isLoading, error, refetch } = useQuery({
    queryKey: ['jobs', week, year, platform],
    queryFn: () => getJobs({ week, year, ...(platform !== 'Alle' && { platform }) }),
  })

  const mutation = useMutation({
    mutationFn: ({ id, status }) => updateJobStatus(id, status),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['jobs'] }),
  })

  const openCount = jobs.filter(j => j.status === 'open').length
  const doneCount = jobs.filter(j => ['delivered','confirmed'].includes(j.status)).length

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-gray-900 text-white px-4 py-4 sticky top-0 z-10">
        <div className="flex items-center justify-between max-w-2xl mx-auto">
          <div>
            <h1 className="font-bold text-lg">CreatorFlow</h1>
            <p className="text-xs text-gray-400">KW{week} · {user?.email}</p>
          </div>
          <div className="flex items-center gap-3">
            <WeekFilter week={week} year={year} onChange={(w,y) => { setWeek(w); setYear(y) }} />
            <button onClick={() => { clearAuth(); navigate('/login') }} className="text-xs text-gray-400 hover:text-white">Abmelden</button>
          </div>
        </div>
      </div>

      <div className="max-w-2xl mx-auto px-4 py-4 space-y-4">
        <div className="grid grid-cols-3 gap-3">
          {[
            { label: 'Gesamt', value: jobs.length, color: 'text-gray-900', border: 'border-gray-200' },
            { label: 'Offen', value: openCount, color: 'text-red-600', border: 'border-red-200' },
            { label: 'Erledigt', value: doneCount, color: 'text-green-600', border: 'border-green-200' },
          ].map(({ label, value, color, border }) => (
            <div key={label} className={`bg-white rounded-xl border ${border} p-3 text-center`}>
              <div className={`text-2xl font-bold ${color}`}>{value}</div>
              <div className="text-xs text-gray-500">{label}</div>
            </div>
          ))}
        </div>

        <div className="flex gap-2 overflow-x-auto pb-1">
          {PLATFORMS.map(p => (
            <button key={p} onClick={() => setPlatform(p)}
              className={`flex-shrink-0 px-3 py-1.5 rounded-lg text-sm font-medium transition-colors ${
                platform === p ? 'bg-indigo-600 text-white' : 'bg-white border border-gray-200 text-gray-600 hover:bg-gray-50'
              }`}>
              {p}
            </button>
          ))}
        </div>

        {isLoading ? (
          <div className="text-center py-12 text-gray-400 text-sm">Lädt…</div>
        ) : error ? (
          <ErrorState error={error} onRetry={refetch} />
        ) : jobs.length === 0 ? (
          <div className="text-center py-12 text-gray-400 text-sm">
            Keine Jobs für KW{week}.
          </div>
        ) : (
          <div className="space-y-3 pb-24">
            {jobs.map(job => (
              <JobCard key={job.id} job={job}
                onStatusChange={(id, status) => mutation.mutate({ id, status })} />
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
