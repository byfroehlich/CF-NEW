import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import { getUser, isLoggedIn } from './lib/auth.js'
import Login from './pages/Login.jsx'
import CreatorDashboard from './pages/CreatorDashboard.jsx'
import AdminDashboard from './pages/AdminDashboard.jsx'

function PrivateRoute({ children, roles }) {
  if (!isLoggedIn()) return <Navigate to="/login" replace />
  const user = getUser()
  if (roles && !roles.includes(user?.role)) return <Navigate to="/login" replace />
  return children
}

export default function App() {
  const user = getUser()

  return (
    <BrowserRouter>
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route path="/" element={
          isLoggedIn()
            ? <Navigate to={['admin','agency'].includes(user?.role) ? '/admin' : '/creator'} replace />
            : <Navigate to="/login" replace />
        } />
        <Route path="/creator" element={
          <PrivateRoute roles={['creator']}>
            <CreatorDashboard />
          </PrivateRoute>
        } />
        <Route path="/admin" element={
          <PrivateRoute roles={['admin','agency']}>
            <AdminDashboard />
          </PrivateRoute>
        } />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </BrowserRouter>
  )
}
