import { Router } from 'express'
import sql from '../db/client.js'
import { requireAuth, requireAgencyOrAdmin } from '../middleware/auth.js'
import { validate, jobStatusSchema } from '../validation/schemas.js'
import { getCurrentWeek } from '../lib/weekHelper.js'

const router = Router()

// GET /api/v1/jobs
router.get('/', requireAuth, async (req, res) => {
  try {
    const { week: currentWeek, year: currentYear } = getCurrentWeek()
    const w = parseInt(req.query.week) || currentWeek
    const y = parseInt(req.query.year) || currentYear
    const { platform } = req.query

    // Datenisolation: Creator sieht nur eigene Jobs
    // Agency sieht nur Jobs ihrer Agentur
    // Admin sieht alles
    let jobs
    if (req.user.role === 'admin') {
      jobs = await sql`
        SELECT j.*, c.name as creator_name FROM jobs j
        JOIN creators c ON c.id = j.creator_id
        WHERE j.week_number = ${w} AND j.year = ${y}
        AND j.deleted_at IS NULL
        ${platform ? sql`AND j.platform = ${platform}` : sql``}
        ORDER BY j.created_at
      `
    } else if (req.user.role === 'agency') {
      jobs = await sql`
        SELECT j.*, c.name as creator_name FROM jobs j
        JOIN creators c ON c.id = j.creator_id
        WHERE j.agency_id = ${req.user.agency_id}
        AND j.week_number = ${w} AND j.year = ${y}
        AND j.deleted_at IS NULL
        ${platform ? sql`AND j.platform = ${platform}` : sql``}
        ORDER BY j.created_at
      `
    } else {
      jobs = await sql`
        SELECT j.*, c.name as creator_name FROM jobs j
        JOIN creators c ON c.id = j.creator_id
        WHERE j.creator_id = ${req.user.creator_id}
        AND j.week_number = ${w} AND j.year = ${y}
        AND j.deleted_at IS NULL
        ${platform ? sql`AND j.platform = ${platform}` : sql``}
        ORDER BY j.created_at
      `
    }

    res.json(jobs)
  } catch (err) {
    console.error(err)
    res.status(500).json({ error: 'Serverfehler' })
  }
})

// GET /api/v1/jobs/summary
router.get('/summary', requireAuth, async (req, res) => {
  try {
    const { week: currentWeek, year: currentYear } = getCurrentWeek()
    const w = parseInt(req.query.week) || currentWeek
    const y = parseInt(req.query.year) || currentYear

    const agencyFilter = req.user.role === 'agency'
      ? sql`AND agency_id = ${req.user.agency_id}`
      : req.user.role === 'creator'
        ? sql`AND creator_id = ${req.user.creator_id}`
        : sql``

    const [summary] = await sql`
      SELECT
        COUNT(*) FILTER (WHERE status = 'open')        as open,
        COUNT(*) FILTER (WHERE status = 'in_progress') as in_progress,
        COUNT(*) FILTER (WHERE status = 'delivered')   as delivered,
        COUNT(*) FILTER (WHERE status = 'confirmed')   as confirmed,
        COUNT(*) FILTER (WHERE carried_over_from IS NOT NULL) as carried,
        COUNT(*) as total
      FROM jobs
      WHERE week_number = ${w} AND year = ${y}
      AND deleted_at IS NULL
      ${agencyFilter}
    `
    res.json(summary)
  } catch (err) {
    res.status(500).json({ error: 'Serverfehler' })
  }
})

// PATCH /api/v1/jobs/:id
router.patch('/:id', requireAuth, validate(jobStatusSchema), async (req, res) => {
  try {
    const { status } = req.body

    // Soft-delete-sichere Suche
    const [existing] = await sql`
      SELECT id, status, creator_id, agency_id FROM jobs
      WHERE id = ${req.params.id} AND deleted_at IS NULL
    `
    if (!existing) return res.status(404).json({ error: 'Job nicht gefunden' })

    // Datenisolation prüfen
    if (req.user.role === 'creator' && existing.creator_id !== req.user.creator_id) {
      return res.status(403).json({ error: 'Keine Berechtigung' })
    }
    if (req.user.role === 'agency' && existing.agency_id !== req.user.agency_id) {
      return res.status(403).json({ error: 'Keine Berechtigung' })
    }

    const now = new Date()
    const [job] = await sql`
      UPDATE jobs SET
        status = ${status},
        in_progress_at = CASE WHEN ${status} = 'in_progress' THEN ${now} ELSE in_progress_at END,
        delivered_at   = CASE WHEN ${status} = 'delivered'   THEN ${now} ELSE delivered_at END,
        confirmed_at   = CASE WHEN ${status} = 'confirmed'   THEN ${now} ELSE confirmed_at END
      WHERE id = ${req.params.id}
      RETURNING *
    `

    // Status-History schreiben
    await sql`
      INSERT INTO job_status_history (job_id, old_status, new_status, changed_by, changed_by_source)
      VALUES (${job.id}, ${existing.status}, ${status}, ${req.user.id}, 'api')
    `

    res.json(job)
  } catch (err) {
    console.error(err)
    res.status(500).json({ error: 'Serverfehler' })
  }
})

// DELETE /api/v1/jobs/:id — Soft delete
router.delete('/:id', requireAgencyOrAdmin, async (req, res) => {
  try {
    const [job] = await sql`
      UPDATE jobs SET deleted_at = now()
      WHERE id = ${req.params.id}
      AND deleted_at IS NULL
      ${req.user.role === 'agency' ? sql`AND agency_id = ${req.user.agency_id}` : sql``}
      RETURNING id
    `
    if (!job) return res.status(404).json({ error: 'Job nicht gefunden' })
    res.json({ ok: true })
  } catch (err) {
    res.status(500).json({ error: 'Serverfehler' })
  }
})

export default router
