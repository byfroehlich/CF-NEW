import { Router } from 'express'
import sql from '../db/client.js'
import { requireAdmin, requireAgencyOrAdmin } from '../middleware/auth.js'

const router = Router()

// GET /api/v1/creators
router.get('/', requireAgencyOrAdmin, async (req, res) => {
  try {
    const creators = req.user.role === 'admin'
      ? await sql`SELECT * FROM creators WHERE deleted_at IS NULL ORDER BY name`
      : await sql`SELECT * FROM creators WHERE agency_id = ${req.user.agency_id} AND deleted_at IS NULL ORDER BY name`

    res.json(creators)
  } catch (err) {
    res.status(500).json({ error: 'Serverfehler' })
  }
})

// PATCH /api/v1/creators/:id — Soft deactivate
router.patch('/:id', requireAgencyOrAdmin, async (req, res) => {
  try {
    const { active } = req.body
    const [creator] = await sql`
      UPDATE creators SET active = ${active}
      WHERE id = ${req.params.id}
      AND deleted_at IS NULL
      ${req.user.role === 'agency' ? sql`AND agency_id = ${req.user.agency_id}` : sql``}
      RETURNING *
    `
    if (!creator) return res.status(404).json({ error: 'Creator nicht gefunden' })
    res.json(creator)
  } catch (err) {
    res.status(500).json({ error: 'Serverfehler' })
  }
})

// DELETE /api/v1/creators/:id — Soft delete
router.delete('/:id', requireAdmin, async (req, res) => {
  try {
    await sql`UPDATE creators SET deleted_at = now() WHERE id = ${req.params.id}`
    res.json({ ok: true })
  } catch (err) {
    res.status(500).json({ error: 'Serverfehler' })
  }
})

export default router
