import { Router } from 'express'
import sql from '../db/client.js'
import { requireAdmin, requireAgencyOrAdmin } from '../middleware/auth.js'

const router = Router()

// GET /api/v1/logs
router.get('/', requireAgencyOrAdmin, async (req, res) => {
  try {
    const { level, source, limit = 150 } = req.query

    // Agency sieht nur eigene Logs
    const agencyFilter = req.user.role === 'agency'
      ? sql`AND (agency_id = ${req.user.agency_id} OR agency_id IS NULL)`
      : sql``

    const logs = await sql`
      SELECT * FROM logs
      WHERE true
      ${level ? sql`AND level = ${level}` : sql``}
      ${source ? sql`AND source = ${source}` : sql``}
      ${agencyFilter}
      ORDER BY created_at DESC
      LIMIT ${Math.min(parseInt(limit), 500)}
    `
    res.json(logs)
  } catch (err) {
    res.status(500).json({ error: 'Serverfehler' })
  }
})

// GET /api/v1/logs/stats
router.get('/stats', requireAgencyOrAdmin, async (req, res) => {
  try {
    const agencyFilter = req.user.role === 'agency'
      ? sql`AND (agency_id = ${req.user.agency_id} OR agency_id IS NULL)`
      : sql``

    const [stats] = await sql`
      SELECT
        COUNT(*) FILTER (WHERE level = 'info'  AND created_at > now() - interval '24 hours') as info_24h,
        COUNT(*) FILTER (WHERE level = 'warn'  AND created_at > now() - interval '24 hours') as warn_24h,
        COUNT(*) FILTER (WHERE level = 'error' AND created_at > now() - interval '24 hours') as error_24h,
        COUNT(*) FILTER (WHERE level = 'error' AND created_at > now() - interval '1 hour')   as error_1h,
        MAX(created_at) FILTER (WHERE event = 'heartbeat')    as last_heartbeat,
        MAX(created_at) FILTER (WHERE event = 'jobs_created') as last_job,
        MAX(created_at) FILTER (WHERE event = 'reply_matched') as last_delivery
      FROM logs
      WHERE true ${agencyFilter}
    `
    res.json(stats)
  } catch (err) {
    res.status(500).json({ error: 'Serverfehler' })
  }
})

export default router
