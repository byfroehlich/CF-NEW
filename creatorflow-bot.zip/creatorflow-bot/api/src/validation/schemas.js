import { z } from 'zod'

export const loginSchema = z.object({
  email: z.string().email('Ungültige E-Mail-Adresse'),
  password: z.string().min(1, 'Passwort erforderlich'),
})

export const jobStatusSchema = z.object({
  status: z.enum(['open', 'in_progress', 'delivered', 'confirmed'],
    { errorMap: () => ({ message: 'Ungültiger Status' }) }
  ),
})

export const setupUserSchema = z.object({
  email: z.string().email(),
  password: z.string()
    .min(12, 'Passwort muss mindestens 12 Zeichen haben')
    .regex(/[A-Z]/, 'Muss einen Großbuchstaben enthalten')
    .regex(/[0-9]/, 'Muss eine Zahl enthalten')
    .regex(/[^A-Za-z0-9]/, 'Muss ein Sonderzeichen enthalten'),
  role: z.enum(['creator', 'agency', 'admin']).default('creator'),
  agency_id: z.string().uuid().optional(),
  creator_id: z.string().uuid().optional(),
})

export function validate(schema) {
  return (req, res, next) => {
    const result = schema.safeParse(req.body)
    if (!result.success) {
      return res.status(400).json({
        error: 'Validierungsfehler',
        details: result.error.errors.map(e => e.message)
      })
    }
    req.body = result.data
    next()
  }
}
