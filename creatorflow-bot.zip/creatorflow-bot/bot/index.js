import { Telegraf } from 'telegraf'
import { config } from 'dotenv'
import cron from 'node-cron'
import { handleMessage } from './src/handlers/onMessage.js'
import { handleReply } from './src/handlers/onReply.js'
import { handleCommand } from './src/handlers/onCommand.js'
import { carryOverJobs } from './src/lib/weekHelper.js'
import { logInfo, logError } from './src/lib/logger.js'
import sql from './src/db/client.js'

config()

const bot = new Telegraf(process.env.BOT_TOKEN)

// Multi-Creator: alle bekannten Chat-IDs aus DB laden
async function getKnownChatIds() {
  const creators = await sql`
    SELECT telegram_chat_id FROM creators
    WHERE telegram_chat_id IS NOT NULL
    AND active = true AND deleted_at IS NULL
  `
  return new Set(creators.map(c => c.telegram_chat_id))
}

bot.on('message', async (ctx) => {
  const knownChats = await getKnownChatIds()
  if (!knownChats.has(ctx.chat.id)) return  // Unbekannter Chat — ignorieren

  const msg = ctx.message
  if (msg.text?.startsWith('/')) return handleCommand(ctx)
  if (msg.reply_to_message && (msg.video || msg.document)) return handleReply(ctx)
  if (msg.text) return handleMessage(ctx)
})

// Heartbeat alle 5 Minuten
cron.schedule('*/5 * * * *', async () => {
  await logInfo('heartbeat', 'Bot online')
})

// Montags 08:00 — automatischer Übertrag aller offenen Jobs
cron.schedule('0 8 * * 1', async () => {
  try {
    const count = await carryOverJobs()
    console.log(`Cron: ${count} Jobs übertragen`)
  } catch (err) {
    await logError('cron_failed', err.message, { stack: err.stack })
  }
})

// Täglich 03:00 — Logs älter als 90 Tage löschen (DSGVO-Löschfrist)
// Läuft AUCH in der API als Fallback
cron.schedule('0 3 * * *', async () => {
  try {
    const result = await sql`
      DELETE FROM logs WHERE created_at < now() - interval '90 days'
    `
    console.log('Cron: alte Logs gelöscht')
  } catch (err) {
    console.error('Log-Cleanup error:', err.message)
  }
})

bot.launch()
await logInfo('bot_start', 'CreatorFlow Bot gestartet')
console.log('✅ CreatorFlow Bot gestartet')

process.once('SIGINT', () => bot.stop('SIGINT'))
process.once('SIGTERM', () => bot.stop('SIGTERM'))
