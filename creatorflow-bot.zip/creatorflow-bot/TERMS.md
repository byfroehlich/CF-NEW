# CreatorFlow — Nutzungsbedingungen & Acceptable Use Policy

**Stand:** April 2025
**Betreiber:** Mathias Fröhlich, by Fröhlich – digitale Automatisierung, Josef-Ahorn-Weg 17, 6682 Vils, Österreich

---

## 1. Geltungsbereich

Diese Nutzungsbedingungen gelten für die Nutzung der Software-Plattform CreatorFlow
(nachfolgend "Plattform") durch Content-Agenturen und Creator (nachfolgend "Nutzer").

---

## 2. Vertragsgegenstand

CreatorFlow ist ein Auftragsmanagement-System für die Koordination von Content-Produktion
zwischen Agenturen und Creators. Die Plattform verwaltet Auftragsmetadaten, Status-Tracking
und Kommunikationsverläufe. Die eigentlichen Inhalte (Videos, Bilder) werden nicht auf
Servern der Plattform gespeichert.

---

## 3. Acceptable Use Policy — Verbotene Nutzung

Die folgenden Nutzungen sind ausdrücklich untersagt:

**3.1 Illegale Inhalte**
Die Nutzung der Plattform zur Koordination, Produktion oder Verbreitung von Inhalten,
die gegen geltende Gesetze verstoßen, ist verboten. Dies umfasst insbesondere:
- Inhalte, die Minderjährige sexuell darstellen oder gefährden (§ 184b StGB DE, § 207a StGB AT)
- Inhalte ohne nachweisliche Altersverifikation aller dargestellten Personen
- Inhalte, die ohne Einwilligung der dargestellten Personen erstellt wurden

**3.2 Altersverifikationspflicht**
Der Betreiber/die Agentur ist verpflichtet sicherzustellen, dass:
- Alle in Inhalten dargestellten Personen das gesetzliche Mindestalter (18 Jahre) erreicht haben
- Entsprechende Altersverifikationsdokumente vorliegen und auf Anfrage vorgelegt werden können
- Creator-Accounts nur volljährigen Personen zugänglich gemacht werden

**3.3 Datenschutz**
- Die Weitergabe von Zugangsdaten an Dritte ist untersagt
- Die Nutzung der Plattform zur Verarbeitung von Daten unbeteiligter Dritter ohne Einwilligung ist untersagt

---

## 4. Datenschutz & DSGVO

**4.1 Verarbeitete Daten**
Die Plattform verarbeitet folgende personenbezogene Daten:
- Kontaktdaten (E-Mail, Name)
- Telegram-Kommunikationsmetadaten (Chat-IDs, Nachrichten-IDs — keine Inhalte)
- Auftragsmetadaten (Plattform, Status, Zeitstempel)
- System-Logs (technische Ereignisse, IP-Adressen)

**4.2 Rechtsgrundlage**
Die Verarbeitung erfolgt auf Basis von Art. 6 Abs. 1 lit. b DSGVO (Vertragserfüllung)
sowie Art. 6 Abs. 1 lit. f DSGVO (berechtigte Interessen).

**4.3 Speicherdauer**
- System-Logs: 90 Tage
- Auftragsdaten: 12 Monate nach Abschluss
- Nutzerdaten: bis zur Kündigung + gesetzliche Aufbewahrungsfristen

**4.4 Keine Video-Speicherung**
Videos und erstellte Inhalte werden nicht auf Servern der Plattform gespeichert.
Es werden ausschließlich Referenz-IDs der auf Drittplattformen gespeicherten Dateien verwaltet.

**4.5 Serverstandort**
Alle Daten werden auf Servern in der EU (Frankfurt, Deutschland) gespeichert.

**4.6 Betroffenenrechte**
Nutzer haben das Recht auf Auskunft, Berichtigung, Löschung und Datenübertragbarkeit.
Anfragen an: datenschutz@byfroehlich.at

---

## 5. Haftungsbeschränkung

**5.1** Der Betreiber haftet nicht für Inhalte, die von Nutzern über die Plattform koordiniert werden.

**5.2** Der Betreiber haftet nicht für Schäden, die durch Missbrauch der Plattform entstehen,
sofern der Missbrauch nicht auf grobe Fahrlässigkeit des Betreibers zurückzuführen ist.

**5.3** Die Haftung für mittelbare Schäden, entgangenen Gewinn und Datenverlust ist ausgeschlossen,
soweit dies gesetzlich zulässig ist.

---

## 6. Kündigung & Datenlöschung

Der Betreiber behält sich vor, Accounts bei Verstößen gegen diese Nutzungsbedingungen
ohne Vorankündigung zu sperren oder zu löschen.

Bei Kündigung werden personenbezogene Daten nach Ablauf der gesetzlichen Aufbewahrungsfristen
vollständig gelöscht.

---

## 7. Auftragsverarbeitungsvertrag (AVV)

Agenturen, die die Plattform kommerziell nutzen, schließen zusätzlich einen
Auftragsverarbeitungsvertrag gemäß Art. 28 DSGVO ab. Dieser ist auf Anfrage erhältlich.

---

## 8. Anwendbares Recht

Es gilt österreichisches Recht unter Ausschluss des UN-Kaufrechts.
Gerichtsstand ist Reutte, Tirol, Österreich.

---

## 9. Kontakt

by Fröhlich – digitale Automatisierung
Mathias Fröhlich
Josef-Ahorn-Weg 17, 6682 Vils, Österreich
legal@byfroehlich.at

---

*Diese Nutzungsbedingungen sind ein Entwurf und sollten vor dem kommerziellen
Einsatz von einem Rechtsanwalt geprüft werden.*
